
let player;
let goods = [];
let cars = [];
let score = 0;
let gameOver = false;
let gameWon = false;
let timer = 60 * 60; // 60 segundos * 60 frames (p5.js roda a 60 fps)

function setup() {
  createCanvas(800, 400);
  player = new Player();

  // Produtos do campo
  for (let i = 0; i < 3; i++) {
    goods.push(new Good());
  }

  // Obstáculos da cidade (aqui, animais ou algo da fazenda)
  for (let i = 0; i < 2; i++) {
    cars.push(new Car());
  }
}

function draw() {
  drawFarmBackground();

  if (!gameOver && !gameWon) {
    player.update();
    player.show();

    for (let g of goods) {
      g.update();
      g.show();

      if (player.collect(g)) {
        score++;
        g.reset();
      }
    }

    for (let c of cars) {
      c.update();
      c.show();

      if (player.hits(c)) {
        gameOver = true;
      }
    }

    // Atualiza timer
    timer--;
    if (timer <= 0) {
      gameOver = true;
    }

    // Verifica se ganhou
    if (score >= 30
       ) {
      gameWon = true;
    }

    fill(0);
    textSize(20);
    text("Entregas: " + score, 10, 30);
    text("Tempo: " + floor(timer / 60), 700, 30); // mostra tempo em segundos
  } else if (gameOver) {
    fill(0);
    textSize(40);
    textAlign(CENTER);
    text("Fim de jogo!", width / 2, height / 2);
    textSize(20);
    text("Pressione R para recomeçar", width / 2, height / 2 + 40);
  } else if (gameWon) {
    fill(0, 150, 0);
    textSize(50);
    textAlign(CENTER);
    text("Você ganhou!", width / 2, height / 2);
    textSize(20);
    text("Pressione R para jogar novamente", width / 2, height / 2 + 40);
  }
}

function keyPressed() {
  if (keyCode === UP_ARROW) player.move(-1);
  if (keyCode === DOWN_ARROW) player.move(1);
  if (key === 'r' || key === 'R') restartGame();
}

// ----- CLASSES -----
// (mantém igual o seu código...)

class Player {
  constructor() {
    this.x = 100;
    this.y = height / 2;
    this.width = 70;
    this.height = 40;
    this.speed = 5;
  }

  update() {
    this.y = constrain(this.y, 0, height - this.height);
  }

  show() {
    // Corpo do caminhão
    fill(255, 165, 0); // laranja
    rect(this.x, this.y + 10, this.width, this.height - 10, 5);

    // Cabine
    fill(200, 100, 0);
    rect(this.x + this.width - 30, this.y, 30, 30, 5);

    // Rodas
    fill(50);
    ellipse(this.x + 20, this.y + this.height, 20, 20);
    ellipse(this.x + 50, this.y + this.height, 20, 20);
  }

  move(dir) {
    this.y += dir * this.speed * 10;
  }

  collect(g) {
    return collideRectRect(this.x, this.y, this.width, this.height, g.x, g.y, g.size, g.size);
  }

  hits(c) {
    return collideRectRect(this.x, this.y, this.width, this.height, c.x, c.y, c.size, c.size);
  }
}

class Good {
  constructor() {
    this.reset();
  }

  reset() {
    this.x = random(width, width + 500);
    this.y = random(height - 40);
    this.size = 30;
    this.speed = 3;
  }

  update() {
    this.x -= this.speed;
    if (this.x < -this.size) this.reset();
  }

  show() {
    fill(255);
    ellipse(this.x, this.y, this.size); // milho/leite
  }
}

class Car {
  constructor() {
    this.reset();
  }

  reset() {
    this.x = random(width, width + 800);
    this.y = random(height - 40);
    this.size = 50;
    this.speed = 4;
  }

  update() {
    this.x -= this.speed;
    if (this.x < -this.size) this.reset();
  }

  show() {
    // Aqui, carro vira um animal que atravessa a fazenda (por exemplo, uma vaca)
    fill(150, 75, 0); // marrom
    rect(this.x, this.y, this.size, this.size * 0.6, 10); // corpo
    fill(0);
    ellipse(this.x + 10, this.y + this.size * 0.6, 15, 15); // cabeça
    fill(255);
    ellipse(this.x + 35, this.y + this.size * 0.8, 20, 20); // pata dianteira
    ellipse(this.x + 50, this.y + this.size * 0.8, 20, 20); // pata traseira
  }
}

function restartGame() {
  score = 0;
  gameOver = false;
  gameWon = false;
  timer = 60 * 60; // reseta o tempo para 60 segundos
  player = new Player();
  goods.forEach(g => g.reset());
  cars.forEach(c => c.reset());
}

function drawFarmBackground() {
  // Céu
  background(135, 206, 235); // azul céu

  // Grama
  noStroke();
  fill(34, 139, 34);
  rect(0, height - 100, width, 100);

  // Cercas
  stroke(139, 69, 19);
  strokeWeight(4);
  for (let i = 0; i < width; i += 50) {
    line(i, height - 100, i, height - 150);
    line(i, height - 150, i + 40, height - 150);
    line(i + 40, height - 150, i + 40, height - 100);
  }
  noStroke();

  // Árvores simples
  fill(34, 139, 34);
  for (let i = 50; i < width; i += 200) {
    ellipse(i, height - 180, 50, 80); // copa
  }
  fill(139, 69, 19);
  for (let i = 50; i < width; i += 200) {
    rect(i - 10, height - 150, 20, 50); // tronco
  }

  // Casinha
  fill(255, 228, 196);
  rect(width - 120, height - 160, 100, 80, 10);
  fill(178, 34, 34);
  triangle(width - 130, height - 160, width - 70, height - 220, width - 10, height - 160);
}

function collideRectRect(x1, y1, w1, h1, x2, y2, w2, h2) {
  return (
    x1 < x2 + w2 &&
    x1 + w1 > x2 &&
    y1 < y2 + h2 &&
    y1 + h1 > y2
  );
}

